to singin you need to set the email and password of the manger 
Email:salahsos100@gmail.com
Password:123456
Enjoy !!!!!!!!
CRM COMPANY
CREATET BY SALAH ABU RATIUSH ©  😊😊   😁😁    😎😎
export const environment = {
  firebase: {
    apiKey: "AIzaSyD70tsD_5fOho9BCnIZ59EnAWO24cfZbGU",
    authDomain: "react-crud-a6923.firebaseapp.com",
    projectId: "react-crud-a6923",
    storageBucket: "react-crud-a6923.appspot.com",
    messagingSenderId: "867975123465",
    appId: "1:867975123465:web:73b08d230bfbf461ceded8"
  },
  production: true
};

export interface Contact {
    name: string;
    email: string;
    birthday: string;
    avatar: string;
    phones?: string[];
}

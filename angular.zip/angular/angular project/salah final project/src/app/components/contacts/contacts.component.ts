import { Contact } from './../../models/contact.model';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ContactsService } from 'src/app/services/contacts.service';
import { Observer, Subscription, Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
})
export class ContactsComponent implements OnInit, OnDestroy {
  headerTitle: string;
  headerIcon: string;
  headerDescription: string;

  nameTerm:string;
  cachedContacts$:Observable<Contact []>=this.contactsService.getContacts().pipe();
  contacts$: Observable<Contact[]>;

  manui:Subscription;

  constructor(private contactsService: ContactsService) {}

  ngOnDestroy(): void {
   
  }

  ngOnInit() {
    console.log("init ContactsComponent")
    this.headerTitle = 'Contacts';
    this.headerIcon = 'fas fa-envelope';
    this.headerDescription = 'The Contacts';


    


    this.contacts$ = this.contactsService.getContacts();


    
  }
  onInputTerm() {
    this.contacts$ = this.cachedContacts$.pipe(
      map((contc: Contact[]) => {
        const filtered = contc?.filter(({ name }: Contact) =>
          name.includes(this.nameTerm)
        );
        return filtered;
      })
    );
  }
}

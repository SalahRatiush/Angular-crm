import { Component, Input, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.css'],
})
export class TopnavComponent implements OnInit {
  @Input('email') userEmail: string = '[user - email]';
  @Input('loggedin') isLogin: boolean = false;

  someFuncINeedToLookInsomeWay: (argument1: number) => void;

  constructor(private auth: AuthService) {
    this.someFuncINeedToLookInsomeWay = this.name;
  }

  signOut(){
    this.auth.logOut();
  }

  ngOnInit(): void {
    this.auth.isLogedIn$.subscribe(x => {
      console.log(x)
    })
  }

  name(params: number) {
    console.log(params);
  }
  name2(params: number) {
    console.log(params);
  }

  event() {
    this.someFuncINeedToLookInsomeWay = this.name2;
  }
}

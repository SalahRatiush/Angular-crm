import { map, shareReplay, switchMap } from 'rxjs/operators';
import { CustomersService } from './../../services/customers.service';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Customer } from 'src/app/models/customer.model';
import { combineLatest, fromEvent, Observable, of } from 'rxjs';


@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css'],
})
export class CustomersComponent implements OnInit, AfterViewInit {

  @ViewChild('input', {static:true}) input: ElementRef;

  headerTitle: string;
  headerIcon: string;
  headerDescription: string;

  customers$: Observable<Customer[]>;
  term: string = '';
  fnameTerm:string='';
  lnameTerm:string='';
  phoneTerm:string='';
  customers: Customer[];
  cachedCustomers$: Observable<Customer[]>;

  constructor(public customersService: CustomersService) {}

  ngAfterViewInit(): void {
    fromEvent(this.input.nativeElement, 'input')
    .pipe(
      switchMap(({srcElement:{value}}:any) => combineLatest([of(value), this.cachedCustomers$])),
      map(([value, customers]) => {
        const filtered = customers.filter(({phone}:Customer) => phone.includes(value))
        return filtered;
      })
    ).subscribe((filtered: Customer[]) => {
      this.customers$ = of(filtered);
    });
  }

  ngOnInit() {
    this.headerTitle = 'Customers';
    this.headerIcon = 'fas fa-user';
    this.headerDescription = 'The Customers';
   
    this.cachedCustomers$ = this.customersService.getCustomers().pipe(shareReplay(1));
    this.customers$ = this.cachedCustomers$;


  }

  remove(id: string) {
    if (confirm('r u sure?')) {
      this.customersService.deleteCustomer(id);
    }
  }

  dateWasThisYear(date: Date): boolean {
    return date.getMonth() < new Date(Date.now()).getMonth();
  }

  onInputTerm(filterType: string) {
    switch (filterType) {
      case 'fname':
        this.customers$ = this.cachedCustomers$.pipe(
          map((custs: Customer[]) => {
            const filtered = custs?.filter(({ firstName }: Customer) =>
              firstName.includes(this.fnameTerm)
            );
            return filtered;
          })
        );
        break;
     case 'lname':
        this.customers$ = this.cachedCustomers$.pipe(
          map((custs: Customer[]) => {
            const filtered = custs?.filter(({ lastName }: Customer) =>
              lastName.includes(this.lnameTerm)
            );
            return filtered;
          })
        );
        break;
     case 'phone':
       this.customers$ = this.cachedCustomers$.pipe(
            map((custs: Customer[]) => {
              const filtered = custs?.filter(({ phone }: Customer) =>
                phone.includes(this.phoneTerm)
              );
              return filtered;
            })
          );
          break;  
    

    

    this.customers$ = this.cachedCustomers$.pipe(
      map((custs: Customer[]) => {
        const filtered = custs?.filter(({phone}:Customer) => phone.includes(this.term))
        return filtered;
      })
    )
  }

}}
